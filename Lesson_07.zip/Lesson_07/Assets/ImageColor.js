﻿#pragma strict

import UnityEngine.UI;

var image : Image;

function ColorChangeRed () {
image.color = Color.red;

}

function ColorChangeBlue () {
image.color = Color.blue;

}