﻿#pragma strict

import UnityEngine.UI;

var slider : Slider;

function ButtonPress() {
Debug.Log(slider.value.ToString());

}
